package com.thingworx.security.authentication;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.thingworx.common.SharedConstants;
import com.thingworx.metadata.annotations.ThingworxConfigurationTableDefinition;
import com.thingworx.metadata.annotations.ThingworxConfigurationTableDefinitions;
import com.thingworx.metadata.annotations.ThingworxDataShapeDefinition;
import com.thingworx.metadata.annotations.ThingworxFieldDefinition;
import com.thingworx.security.authentication.CustomAuthenticator;
import com.thingworx.types.InfoTable;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import com.thingworx.logging.LogUtilities;

@ThingworxConfigurationTableDefinitions(tables = {
		@ThingworxConfigurationTableDefinition(name = "UserMashups", description = "This will contain a list of mashups", isMultiRow = true, ordinal = 0, dataShape = @ThingworxDataShapeDefinition(fields = {
				@ThingworxFieldDefinition(name = "MashupName", description = "", baseType = "STRING", ordinal = 0, aspects = {
				"isRequired:true" }),
				@ThingworxFieldDefinition(name = "UserName", description = "", baseType = "STRING", ordinal = 1, aspects = {
				"isRequired:true" }),
				@ThingworxFieldDefinition(name = "Active", description = "", baseType = "BOOLEAN", ordinal = 2, aspects = {
				"isRequired:true" }),
				@ThingworxFieldDefinition(name = "ContainsParameter", description = "", baseType = "BOOLEAN", ordinal = 3, aspects = {
				"isRequired:true" }),
				@ThingworxFieldDefinition(name = "ParameterValueList", description = "contains json file with Param: 'allowed value list separated by ; '", baseType = "JSON", ordinal = 5),
				@ThingworxFieldDefinition(name = "AllowedParameterList", description = "\" ; \" saparated paratmeters", baseType = "STRING", ordinal = 4) })) })

public class CustomAuth extends CustomAuthenticator {
	private static final long serialVersionUID = 1L;
	private String userNameAccess="";
	private String parameterList="";
	private String parameterAvailable="false";
	private JSONObject  jsonObj;
	protected static final Logger _logger = LogUtilities.getInstance().getApplicationLogger(CustomAuth.class);
	public CustomAuth() {
		// TODO Auto-generated constructor stub
	}

	//@SuppressWarnings("deprecation")
	@Override
	public void authenticate(HttpServletRequest httpRequest, HttpServletResponse httpResponse)

			throws AuthenticatorException {

		// TODO Auto-generated method stub
		if(parameterAvailable == "false")
		{
			this.allowAccess();
		}
		else
		{
			String[] parameterList = this.parameterList.split(";");
			int totalParameters = parameterList.length;
			for(int y=0; y < totalParameters; y++)
			{				
				String paramName =(String)parameterList[y].toString();
				String parameter = httpRequest.getParameter(paramName); // gets the value of our URL parameter viewer
				if(parameter == null || parameter.length() == 0) // if the parameter was not supplied then drop out.
				{
					if(y == (parameterList.length)-1)
					{
						this.setRequiresChallenge(true);

						throw new AuthenticatorException("missing username parameter.  Go through normal challenge process");
					}
				}
				else
				{
					try {
						String valueList = this.jsonObj.getString(paramName);
						if(valueList.contains(parameter))
						{
							this.allowAccess();
						}
						else
						{
							this.goForNormalAuthentication();
						}
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						this.allowAccess();
					}				
					break;
				}
			}		

		}

	}

	@Override

	public void issueAuthenticationChallenge(HttpServletRequest httpRequest, HttpServletResponse httpResponse)

			throws AuthenticatorException {

		// TODO Auto-generated method stub

		//Use for SSO

		this.setRequiresChallenge(true);

		throw new AuthenticatorException("we shouldn't be here"); // I'm not using single sign on but I want to know if we accidentally get here some how.

	}

	private void goForNormalAuthentication()
			throws AuthenticatorException {
		this.setRequiresChallenge(true);

		throw new AuthenticatorException("Viewer not defined. Going through normal authentication");
	}
	private void allowAccess()
			throws AuthenticatorException {
		try{

			// validates the user name

			AuthenticationUtilities.validateThingworxUser(this.userNameAccess);

			// This function does not check the password it just validates that the account supplied is enabled in Thingworx

			// Tells thingworx the user to run as

			this.setCredentials(this.userNameAccess);

			// Tells Thingworx to proceed from a successful login attempt

			// This next line took me the longest to find and was missing from most examples.  It is needed to actually continue on to the page the

			// URL is trying to get to

			AuthenticationUtilities.getSecurityMonitorThing().fireSuccessfulLoginEvent(this.userNameAccess, SharedConstants.EMPTY_STRING);

		}

		catch(Exception e){

			this.setRequiresChallenge(true);

			throw new AuthenticatorException("exception in case");

		}
	}

	@Override

	public boolean matchesAuthRequest(HttpServletRequest httpRequest) throws AuthenticatorException {

		// TODO Auto-generated method stub
		Boolean reqAuth= false;
		String requestURI = httpRequest.getRequestURI();
		try {
			InfoTable configTable = this.GetConfigurationTable("UserMashups");
			int rowLength = configTable.getRowCount();
			for(int i=0; i< rowLength; i++)
			{
				String MashupName = (String)configTable.getRow(i).getStringValue("MashupName");
				if(requestURI.contains(MashupName)) 
				{
					String activeStatus = (String)configTable.getRow(i).getStringValue("Active");
					if(activeStatus == "true")
					{
						reqAuth = true;
						String userName = (String)configTable.getRow(i).getStringValue("UserName");
						this.userNameAccess = userName;
						this.parameterAvailable = (String)configTable.getRow(i).getStringValue("ContainsParameter");
						this.parameterList = (String)configTable.getRow(i).getStringValue("AllowedParameterList");
						this.jsonObj = (JSONObject)configTable.getRow(i).getJSONSerializedValue("ParameterValueList");
						break;

					}
				}
			}		

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			this.goForNormalAuthentication();
		}
		if(reqAuth)
		{

			return true;
		}
		else
		{
			this.setRequiresChallenge(true);

			throw new AuthenticatorException(requestURI);
		}

	}

}
